//
//  ViewController.swift
//  MarvelRandomizer
//
//  Created by Arman Myrzakanurov on 04.06.2022.
//

import UIKit
import Kingfisher

final class ViewController: UIViewController {
    
    @IBOutlet private weak var heroImage: UIImageView!
    @IBOutlet private weak var heroName: UILabel!
    
    var manager = MarvelManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        manager.delegate = self
        if let data = UserDefaults.standard.data(forKey: "hero"),
           let heroModel = try? PropertyListDecoder().decode(HeroResponse.self, from: data) {
            onHeroModelDidUpdate(with: heroModel)
        }
    }
    
    @IBAction private func buttonDidTap(_ sender: UIButton) {
        let randomId = Int.random(in: 1...730)
        manager.fetchHero(with: randomId)
    }
}

// MARK: - MarvelManagerDelegate

extension ViewController: MarvelManagerDelegate {
    
    func onHeroModelDidUpdate(with model: HeroResponse) {
        heroName.text = model.name
        if let imageUrl = URL(string: model.images.lg) {
            heroImage.kf.setImage(with: imageUrl)
        }
        if let data = try? PropertyListEncoder().encode(model) {
            UserDefaults.standard.set(data, forKey: "hero")
        }
    }
}
