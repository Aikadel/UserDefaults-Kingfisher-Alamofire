//
//  HeroResponse.swift
//  MarvelRandomizer
//
//  Created by Arman Myrzakanurov on 04.06.2022.
//

import Foundation

struct HeroResponse: Codable {
    let name: String
    let images: HeroImage
}

struct HeroImage: Codable {
    let lg: String
}
