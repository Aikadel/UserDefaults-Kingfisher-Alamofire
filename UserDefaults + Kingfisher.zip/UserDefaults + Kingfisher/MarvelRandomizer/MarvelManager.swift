//
//  MarvelManager.swift
//  MarvelRandomizer
//
//  Created by Arman Myrzakanurov on 04.06.2022.
//

import Foundation
import Alamofire

protocol MarvelManagerDelegate: AnyObject {
    func onHeroModelDidUpdate(with model: HeroResponse)
}

struct MarvelManager {
    
    weak var delegate: MarvelManagerDelegate?
    
    func fetchHero(with id: Int) {
        let urlString = "https://akabab.github.io/superhero-api/api/id/\(id).json"
        
        AF.request(urlString).responseDecodable(of: HeroResponse.self) { response in
            switch response.result {
            case .success(let model):
                delegate?.onHeroModelDidUpdate(with: model)
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
}
